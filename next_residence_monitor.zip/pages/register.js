import { useState } from 'react'
import { useRouter } from 'next/router'

export default function Register(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [name,setName]=useState('')
  const router = useRouter()

  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/auth/register', {
      method:'POST',
      headers:{'content-type':'application/json'},
      body: JSON.stringify({ email, password, name })
    })
    const data = await res.json()
    if (res.ok) {
      alert('Registered. Please login.')
      router.push('/')
    } else {
      alert(data.error || 'Register failed')
    }
  }

  return (
    <div style={{display:'flex', alignItems:'center', justifyContent:'center', minHeight:'100vh', background:'#f3f4f6'}}>
      <form onSubmit={submit} style={{background:'#fff', padding:24, borderRadius:8, boxShadow:'0 2px 8px rgba(0,0,0,0.1)', width:360}}>
        <h2 style={{marginBottom:16}}>Daftar — Residence Monitor</h2>
        <input placeholder="Nama" value={name} onChange={e=>setName(e.target.value)} style={inputStyle}/>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} style={inputStyle}/>
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} style={inputStyle}/>
        <button style={btnStyle}>Daftar</button>
        <p style={{marginTop:12, fontSize:14}}>Sudah punya akun? <a href="/">Login</a></p>
      </form>
    </div>
  )
}

const inputStyle = {width:'100%', padding:10, marginBottom:10, borderRadius:6, border:'1px solid #ddd'}
const btnStyle = {width:'100%', padding:10, borderRadius:6, border:'none', background:'#111827', color:'#fff'}
